package main;

import com.formdev.flatlaf.FlatDarkLaf;
import gui.LoginForm;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        // Apply FlatLaf Dark modern theme
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception e) {
            System.err.println("Failed to apply FlatLaf theme: " + e.getMessage());
        }

        java.awt.EventQueue.invokeLater(() -> {
            LoginForm login = new LoginForm();
            login.setLocationRelativeTo(null); // center on screen
            login.setVisible(true);
        });
    }
}