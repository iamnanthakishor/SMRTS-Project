# SMRTS v2.0 — Smart Maintenance Request & Tracking System

## What's New in v2.0

| Feature | v1.0 | v2.0 |
|---------|------|------|
| UI Theme | Default grey Swing | Modern dark (FlatLaf) |
| Password security | Plain text | BCrypt hashed |
| Technician CRUD | Add only | Full Add/Update/Delete/Search |
| Technician table | Empty | Loads from DB, click-to-fill |
| Maintenance Requests | ❌ | ✅ Full CRUD + status filter |
| Admin Dashboard | Welcome label | Stats cards + sidebar nav |
| Architecture | JFrame forms | Embedded panels in CardLayout |

---

## Setup Steps

### 1. Database
Open MySQL Workbench (or phpMyAdmin) and run:
```
database_setup.sql
```
Default login: **username:** `admin`  **password:** `admin123`

### 2. Update DB password in code
Open `src/main/java/database/DBConnection.java` and change:
```java
private static final String PASSWORD = "2004";  // ← your MySQL password
```

### 3. Add dependencies (pom.xml is ready)
In NetBeans: Right-click project → **Clean and Build**
Maven will auto-download:
- `flatlaf-3.4.jar` (modern UI)
- `jbcrypt-0.4.jar` (password hashing)
- `mysql-connector-j-9.7.0.jar`

### 4. Run
Right-click `Main.java` → **Run File**

---

## Project Structure

```
src/main/java/
├── main/
│   └── Main.java                  ← Entry point (sets FlatLaf theme)
├── database/
│   └── DBConnection.java          ← MySQL connection
├── model/
│   ├── Technician.java
│   └── MaintenanceRequest.java    ← NEW: with Priority & Status enums
├── dao/
│   ├── TechnicianDAO.java         ← Full CRUD + search + count
│   └── MaintenanceRequestDAO.java ← NEW: Full CRUD + filter + count
└── gui/
    ├── LoginForm.java             ← Modern login (pure code, no .form file)
    ├── AdminDashboard.java        ← Sidebar + CardLayout shell + stats
    ├── TechnicianForm.java        ← Panel (embedded, not JFrame)
    └── MaintenanceRequestForm.java← NEW: Panel with status badges
```

---

## Security Note
The BCrypt hash in `database_setup.sql` is for password `admin123`.
To hash a new password, use this snippet in a test class:
```java
import org.mindrot.jbcrypt.BCrypt;
String hashed = BCrypt.hashpw("yourNewPassword", BCrypt.gensalt());
System.out.println(hashed);
// Then UPDATE users SET password='...' WHERE username='admin';
```
